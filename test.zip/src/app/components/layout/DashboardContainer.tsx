// src/components/DashboardContainer.tsx
import React from 'react';

// Component này nhận 'children' để có thể chứa các component khác bên trong nó
const DashboardContainer = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="bg-zinc-900 rounded-2xl p-6 shadow-lg">
      {children}
    </div>
  );
};

export default DashboardContainer;