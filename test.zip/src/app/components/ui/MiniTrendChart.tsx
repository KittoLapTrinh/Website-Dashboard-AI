// src/components/widgets/MiniTrendChart.tsx
import React from 'react';

interface MiniTrendChartProps {
  trend: 'up' | 'down';
}

const MiniTrendChart = ({ trend }: MiniTrendChartProps) => {
  // Xác định màu và đường đi của SVG dựa trên 'trend'
  const colorClass = trend === 'up' ? 'text-green-500' : 'text-red-500';
  const path = trend === 'up' 
    ? "M2 20 Q 10 5, 20 10 T 38 8" 
    : "M2 10 Q 10 25, 20 20 T 38 22";

  return (
    <svg width="40" height="28" viewBox="0 0 40 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d={path} className={`stroke-current ${colorClass}`} strokeWidth="2" strokeLinecap="round" />
      <circle 
        cx={38} 
        cy={trend === 'up' ? 8 : 22} 
        r="3" 
        className={`fill-current ${colorClass}`} 
      />
    </svg>
  );
};

export default MiniTrendChart;