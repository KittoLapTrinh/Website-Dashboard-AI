// src/components/WidgetCard.tsx - SAU KHI CHỈNH SỬA
import React from 'react';

const WidgetCard = ({ children }: { children: React.ReactNode }) => {
  return (
    // 👇 THÊM class h-full VÀO ĐÂY 👇
    <div className="bg-black rounded-2xl p-6 h-full">
      {children}
    </div>
  );
};

export default WidgetCard;