// src/components/widgets/AnalyticsChart.tsx
import React from 'react';
import WidgetCard from '../ui/WidgetCard';
import { ChevronDown, TrendingUp } from 'lucide-react';

const AnalyticsChart = () => {
  return (
    <WidgetCard>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Analytics</h2>
            <p className="text-sm text-gray-400">April 2025</p>
          </div>
          <button className="flex items-center gap-x-2 text-sm text-gray-300 border border-gray-600 hover:bg-gray-700/50 rounded-full px-3 py-1 transition-colors">
            Weekly
            <ChevronDown size={16} />
          </button>
        </div>

        {/* Chart Area */}
        <div className="flex-grow relative mt-4">
          {/* SVG Chart */}
          <svg width="100%" height="100%" viewBox="0 0 300 150" preserveAspectRatio="none">
            {/* Gradient Definition */}
            <defs>
              <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
              </linearGradient>
            </defs>
            
            {/* Gradient Area */}
            <path d="M 0 80 C 40 40, 60 120, 100 80 S 150 20, 200 60 S 260 100, 300 70 V 150 H 0 Z" fill="url(#chartGradient)" />

            {/* Line */}
            <path d="M 0 80 C 40 40, 60 120, 100 80 S 150 20, 200 60 S 260 100, 300 70" stroke="#a7a7a7" fill="none" strokeWidth="2" />
          </svg>

          {/* Tooltip (đặt ở vị trí giả lập) */}
          <div className="absolute" style={{ top: '45%', left: '28%' }}>
            {/* Dotted line */}
            <div className="absolute bottom-full left-1/2 w-px h-8 bg-dotted-line"></div>
            {/* Circle */}
            <div className="w-5 h-5 rounded-full bg-white border-4 border-blue-500 transform -translate-x-1/2 -translate-y-1/2"></div>
            {/* Tooltip box */}
            <div className="absolute bottom-full left-1/2 mb-4 transform -translate-x-1/2 bg-zinc-800 text-white p-2 rounded-lg shadow-lg w-32 text-center">
              <div className="flex justify-between items-center text-xs">
                <span>82%</span>
                <TrendingUp size={14} className="text-green-500" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </WidgetCard>
  );
};

export default AnalyticsChart;

// Helper để tạo background dotted line
// Thêm vào file globals.css của bạn:
/*
.bg-dotted-line {
  background-image: linear-gradient(to bottom, #a7a7a7 50%, transparent 50%);
  background-size: 1px 8px;
}
*/