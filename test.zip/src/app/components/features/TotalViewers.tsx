

import { ChevronDown, TrendingUp } from 'lucide-react';

import WidgetCard from '../ui/WidgetCard';

const TotalViewers = () => {
  return (
    // 2. Bọc toàn bộ nội dung bằng WidgetCard
    <WidgetCard>
      {/* Nội dung bên trong không thay đổi */}
      <div className="flex justify-between items-start">
        {/* Cột bên trái */}
        <div className="flex flex-col gap-y-2">
          <p className="text-gray-400 text-sm">Total Viewers</p>
          <p className="text-4xl font-bold text-white">12,304.11</p>
          <div className="flex items-center gap-x-2">
            <span className="text-sm text-gray-400">Return</span>
            <span className="flex items-center gap-x-1 text-sm bg-green-900/50 text-green-400 border border-green-700/60 rounded-full px-2 py-0.5">
              <TrendingUp size={16} />
              +3.5%
            </span>
          </div>
        </div>

        {/* Cột bên phải */}
        <div className="flex items-center gap-x-2">
          <button className="text-sm text-gray-300 border border-gray-600 hover:bg-gray-700/50 rounded-full px-3 py-1 transition-colors">
            6M
          </button>
          <button className="p-1.5 border border-gray-600 hover:bg-gray-700/50 rounded-full transition-colors">
            <ChevronDown size={18} className="text-gray-300" />
          </button>
        </div>
      </div>
    </WidgetCard>
  );
};

export default TotalViewers;