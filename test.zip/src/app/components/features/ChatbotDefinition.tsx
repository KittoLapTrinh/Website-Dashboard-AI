// src/components/features/ChatbotDefinition.tsx - ĐÃ SỬA ĐỂ XẾP CHỒNG ẢNH

import React from 'react';
import Image from 'next/image';
import WidgetCard from '../ui/WidgetCard';
import { Send } from 'lucide-react';
import Chatbot1 from '@/app/assets/image/Chatbot1.png';
import Chatbot2 from '@/app/assets/image/Chatbot2.png';

const ChatbotDefinition = () => {
  return (
    <WidgetCard>
      <h2 className="text-2xl font-bold text-white mb-6">
        <span className=" pb-1">
          Chat Bot Definition
        </span>
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mt-8">
        
        {/* Cột trái: Hình ảnh được xếp chồng */}
        <div className="relative aspect-square max-w-md mx-auto">
          {/* LỚP NỀN: Hiệu ứng xoáy (z-10) */}
          <Image
            src={Chatbot2} 
            alt="Vortex background effect"
            fill
            className="object-contain z-10" // Đặt ở lớp dưới
          />
          {/* LỚP TRÊN: Con robot (z-20) */}
          <Image
            src={Chatbot1} 
            alt="Friendly chatbot character"
            fill
            className="object-contain z-20" // Đặt ở lớp trên
          />
        </div>

        {/* Cột phải: Giao diện Chat (giữ nguyên) */}
        <div className="flex flex-col gap-y-4">
          <div className="chat-bubble-bot">
            <h3 className="font-bold text-white">Menu Leave Rate (20%)</h3>
            <p className="text-sm text-gray-300 mt-2 leading-relaxed">
              A 20% menu leave rate indicates that a significant portion of customers
              are navigating away without taking further action. This could suggest
              that the menu might not be engaging enough or that users are not
              finding what they're looking for quickly. It's essential to investigate the
              reasons behind this drop-off and consider optimizing the menu layout,
              content, or user experience to reduce this rate.
            </p>
          </div>
          <div className="chat-bubble-user">
            <p className="text-sm text-gray-300">This technology is really impressive.</p>
          </div>
          <div className="flex gap-x-2 pt-4">
            {['Any employee ?', 'Any employee ?', 'technology ?'].map((text, i) => (
              <button key={i} className="bg-zinc-700/80 hover:bg-zinc-700 text-xs text-gray-300 px-3 py-1.5 rounded-lg transition-colors">
                {text}
              </button>
            ))}
          </div>
          <div className="relative mt-2">
            <input
              type="text"
              placeholder="This technology is really impressive. ..."
              className="w-full bg-zinc-800 border border-transparent rounded-lg pl-4 pr-14 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
            />
            <button className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-gradient-to-br from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 w-10 h-10 rounded-full flex items-center justify-center transition-all">
              <Send size={18} className="text-white" />
            </button>
          </div>
        </div>
      </div>
    </WidgetCard>
  );
};

export default ChatbotDefinition;