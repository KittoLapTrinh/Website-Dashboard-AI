// src/components/widgets/HeartbeatMonitor.tsx
import React from 'react';
import WidgetCard from '../ui/WidgetCard';
import { HeartPulse, Thermometer, Activity } from 'lucide-react';

const MonitorCard = ({ title, value, unit, icon, chartPath, borderColor = 'border-gray-700' }: any) => {
  return (
    <div className={`bg-zinc-900/50 p-4 rounded-xl border-t-2 ${borderColor}`}>
      <div className="flex items-center gap-x-2 text-sm text-gray-300">
        {icon}
        <span>{title}</span>
      </div>
      <div className="relative h-20 mt-2">
        <svg width="100%" height="100%" viewBox="0 0 100 50" preserveAspectRatio="none">
          <path d={chartPath} stroke="#a7a7a7" strokeWidth="2" fill="none" />
        </svg>
        <div className="absolute right-0 bottom-0 bg-zinc-800 p-2 rounded-md">
          <p className="text-white font-bold text-lg">{value}</p>
          <p className="text-gray-400 text-xs">{unit}</p>
        </div>
      </div>
    </div>
  );
};

const HeartbeatMonitor = () => {
  return (
    <WidgetCard>
      <div className="flex flex-col h-full">
        <h2 className="text-xl font-bold text-white mb-4">Heartbeat Monitor</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 flex-grow">
          <MonitorCard
            title="Blood Status"
            value="102"
            unit="I70"
            icon={<HeartPulse size={16} />}
            chartPath="M 0 30 Q 10 10, 20 30 T 40 25 T 60 35 T 80 20 L 80 10"
          />
          <MonitorCard
            title="Temperature"
            value="34.1"
            unit=""
            icon={<Thermometer size={16} />}
            chartPath="M 0 40 L 60 40 L 80 20"
          />
          <MonitorCard
            title="Heart Rate"
            value="102"
            unit="bpm"
            icon={<Activity size={16} />}
            chartPath="M 0 30 L 10 30 L 15 20 L 25 40 L 35 10 L 45 30 L 55 25 L 60 30 L 80 30"
            borderColor="border-green-500"
          />
        </div>
      </div>
    </WidgetCard>
  );
};

export default HeartbeatMonitor;