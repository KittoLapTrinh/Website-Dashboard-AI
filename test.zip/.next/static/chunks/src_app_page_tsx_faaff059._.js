(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_6753bcb1._.js",
  "static/chunks/node_modules_fb7f2a7a._.js",
  "static/chunks/src_app_components_2f93f4ad._.js"
],
    source: "dynamic"
});
